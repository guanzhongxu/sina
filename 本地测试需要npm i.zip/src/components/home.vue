<template>
  <div>
    <!--头部-->
      <div class="layout header">
        <!--头部logo部分-->
        <div id="logo">
            <h1>
              <div class="logo"></div>
            </h1>
            <p class="slogan">
              中文邮箱第一品牌
            </p>
        </div>
        <!--头部选项部分-->
        <div class="select">
          <ul>
            <li><a href="javascript:;">企业邮箱</a></li>
            <li><a href="javascript:;">VIP邮箱</a></li>
            <li><a href="javascript:;">国外用户登录</a></li>
            <li><a href="javascript:;">手机版</a></li>
            <li><a href="javascript:;">电脑版</a></li>
            <li><a href="javascript:;">帮助</a></li>
            <li><a href="javascript:;">常见问题</a></li>
            <li><a href="javascript:;">私人助理</a></li>
            <li><a href="javascript:;">登录反馈</a></li>
          </ul>
        </div>
      </div>
    <!--头部结束-->
    <div class="layout main">
      <a href="javascript:;">
        <img src="../assets/promPic.jpg" alt="">
      </a>
      <div class="logoin">
        <div class="login-header">
          <span>
            <a href="javascript:;">二维码登录</a>
          </span>
          <span>
            <a href="javascript:;">邮箱帐号登录</a>
          </span>
        </div>
        <div class="user-info">
          <div class="form-group">
            <span  class="user"></span>
            <input type="text" placeholder="邮箱账号或手机号码" name="user">
            <span class="email">@163.com</span>
          </div>
          <div class="margin-top"></div>
          <div class="form-group">
            <span  class="lock"></span>
            <input type="password" placeholder="请输入您的密码" name="password">
          </div>
          <div class="tail">
            <span>
              <label>
                <input type="checkbox">
              十天内免密登录
              </label>
            </span>
            <span>
              <a href="javascript:;">忘记密码?</a>
            </span>
          </div>
          <div class="margin-top"></div>
          <div class="button">
            <button class="login">登录</button>
            <button class="register">注册</button>
          </div>
          <p class="tuijian">
            <a href="javascript:;">
              <img src="../assets/tuijian.png" alt="">
            </a>
          </p>
          <div class="bottom-info">
            <p><a href="javascript:;">白色情人节礼物攻略>></a></p>
            <p><a href="javascript:;">网易邮箱提醒您谨防邮件诈骗！</a></p>
          </div>
        </div>
      </div>
    </div>
      <span class="gg"><img src="../assets/gg.png" alt=""></span>
    <span class="left">
      <img src="../assets/left.png" alt="">
    </span>
    <span class="right">
      <img src="../assets/right.png" alt="">
    </span>
  </div>
</template>
<script>
  export default {

  }
</script>
<style scoped>
  /*版心*/
.layout{
  width:968px;
  margin: 0 auto;
}
  /*登录页面的距离*/
  .margin-top {
    height: 20px;
  }
  /*头部区域*/
.header {
  height: 64px;
  display: flex;
  flex:1;
}
/*logo部分*/
.header #logo {
  width: 429px;
  height: 100%;
  margin: 0;
}
.header #logo::after{
  display: block;
  content: ".";
  visibility:hidden;
  clear: both;
  height: 0;
}
.header #logo h1,p {
    float:left
}
  .header #logo p{
    margin-left: 10px;
    padding-left: 10px;
    border-left: 1px solid #777;
    line-height: 30px;
    color: #777;
  }
.header #logo .logo {
  width: 136px;
  height: 32px;
  background: url("../assets/logo.png") no-repeat center center;
  background-size: 100% 100%;
}
/*logo部分结束 */
/*头部选项部分*/
.header .select{
  width: 530px;
  height: 100%;
  margin: 0;
}
  .header .select ul {
    list-style: none;
    padding: 0;
  }
  .header .select ul::after{
    display: block;
    content: ".";
    height: 0;
    visibility: hidden;
    clear:both;
  }
  .header .select ul>li {
    float: left;
    font-size: 12px;
    padding-left: 13px;
    line-height: 32px;
  }
  .header .select ul>li>a {
    color: #777;
    text-decoration: none;
  }
  .header .select ul>li>a:hover {
    color:#000;
  }
  /*头部选项部分结束*/
  /*头部结束*/
  .main {
    position: relative;
  }
  .main .logoin {
    width: 452px;
    height: 472px;
    /*background-color: greenyellow;*/
    position: absolute;
    top: 30px;
    right:0px;
    box-shadow: 0 0 10px rgba(0,0,0,0.6);
  }
  .main .logoin .login-header {
    display: flex;
    justify-content: space-around;
  }
  .main .logoin .login-header>span>a {
    line-height: 35px;
    color: #777;
    text-decoration: none;
    display: block;
    box-sizing: border-box;
  }
  .main .logoin .login-header>span>a:hover {
    box-sizing: border-box;
    color: #22a6ff;
    border-bottom: 2px solid #22a6ff;
  }
  .logoin .user-info{
    width: 330px;
    height: 230px;
    /*background-color: yellowgreen;*/
    margin: 88px auto 0;
    line-height: 44px;
  }

  .logoin .user-info .form-group {
    height: 44px;
    border: 1px solid #777;
    margin: 0;
    box-sizing: border-box;
    position: relative;
    padding-left: 4px;
  }
  .logoin .user-info .form-group .user {
    display: inline-block;
    width:22px;
    height: 24px;
    background: url("../assets/sp.png") no-repeat -251px -86px;
    margin-right:4px;
  }
  .logoin .user-info .form-group input {
    width: 60%;
    height: 96%;
    outline: none;
    border: none;
    background-color: #EEF2FD;
    position: absolute;
    top:0;
  }
  .logoin .user-info .form-group .email{
    position: absolute;
    left: 75%;
  }
  /*用户密码*/
  .logoin .user-info .form-group .lock {
    display: inline-block;
    width:22px;
    height: 24px;
    background: url("../assets/sp.png") no-repeat -291px -86px;
    margin-right:4px;
  }
  /*忘记密码和记住密码*/
  .logoin .user-info .tail{
    display: flex;
    justify-content: space-between;
    font-size: 13px;
  }
  .logoin .user-info .tail label {
    color: #777;
    cursor: pointer;
  }
  .logoin .user-info .tail a {
    color: #226aff;
    text-decoration: none;
  }
  /*注册和登录*/
  .logoin .user-info .button {
    display: flex;
    justify-content: space-between;
    height: 48px;
  }
  .logoin .user-info .login {
     background: #226aff;
     border: none;
     width: 45%;
     border-radius: 10px;
     color: #fff;
    font-size:20px;
   }
  .logoin .user-info .login:hover {
    background-color: #227aff;
  }
  .logoin .user-info .register {
    background: #d6e6f7;
    border: 1px solid #abccef;
    width: 45%;
    border-radius: 10px;
    color: #3182D9;
    font-size:20px;
  }
  .logoin .user-info .register:hover {
    background-color: #abccef;
  }
  /*推荐*/
  .logoin .user-info .tuijian {
    width: 100%;
  }

  .logoin .user-info .tuijian>a{
    display: block;
    width: 100%;
    height: 100%;
    text-align: center;
  }

  .logoin .bottom-info>p {
    display: block;
    margin: 0;
    font-size: 14px;
    line-height: 18px;
  }
  .logoin .bottom-info p>a {
       color: #777;
  }
  .gg {
    position: absolute;
    width: 22px;
    height: 22px;
    bottom: 0;
    left: 50%
  }
  .left,
  .right {
    position: absolute;
    bottom: 10px;
  }
  .left>img,
  .right>img{
    width: 50%;
  }
  .left {
    left:70%;
  }
  .right {
    left: 75%;
  }
</style>
